---@module Features.Visuals.Objects.InstanceESP
local InstanceESP = require("Features/Visuals/Objects/InstanceESP")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@class ModelESP: InstanceESP
---@field model Model
local ModelESP = setmetatable({}, { __index = InstanceESP })
ModelESP.__index = ModelESP
ModelESP.__type = "ModelESP"

---@param self ModelESP
---@param tags string[]
ModelESP.update = LPH_NO_VIRTUALIZE(function(self, tags)
	local model = self.model

	if not model.Parent then
		return self:visible(false)
	end

	InstanceESP.update(self, model:GetPivot().Position, tags or {})
end)

---@param identifier string
---@param model Model
---@param label string
function ModelESP.new(identifier, model, label)
	if not model:IsA("Model") then
		return error(string.format("ModelESP expected model on %s creation.", identifier))
	end

	local self = setmetatable(InstanceESP.new(model, identifier, label), ModelESP)
	self.model = model

	if not Configuration.expectOptionValue("NoPersisentESP") then
		self.model.ModelStreamingMode = Enum.ModelStreamingMode.Persistent
	end

	return self
end

return ModelESP
