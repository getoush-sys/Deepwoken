local clientPart = Instance.new("Part", workspace)
local clientSuccess, clientPeerId = pcall(function()
	return gethiddenproperty(clientPart, "NetworkOwnerV3")
end)

clientPart:Destroy()






---@param part BasePart
---@return boolean
local function hasNetworkOwnership(part)
	local exploitFallback = isnetworkowner or function(...)
		return false
	end

	return exploitFallback(part)
end

return LPH_NO_VIRTUALIZE(function()
	local OwnershipWatcher = { modelsToScan = {}, parts = {} }

	local runService = game:GetService("RunService")

	---@module Utility.Maid
	local Maid = require("Utility/Maid")

	---@module Utility.Configuration
	local Configuration = require("Utility/Configuration")

	---@module Utility.Signal
	local Signal = require("Utility/Signal")

	---@module Utility.InstanceWrapper
	local InstanceWrapper = require("Utility/InstanceWrapper")

	---@module Utility.Logger
	local Logger = require("Utility/Logger")

	---@module Features.Automation.EchoFarm
	local EchoFarm = require("Features/Automation/EchoFarm")

	---@module Utility.Throttle
	local throttle = require("Utility/Throttle")

	local renderStepped = Signal.new(runService.RenderStepped)

	local ownershipMaid = Maid.new()

	local function cleanParts()
		for _, maid in next, OwnershipWatcher.modelsToScan do
			maid:clean()
		end
	end

	---@param character Model
	local function onLiveAdded(character)
		if not character:IsA("Model") then
			return
		end

		if OwnershipWatcher.modelsToScan[character] then
			return
		end

		OwnershipWatcher.modelsToScan[character] = Maid.new()
	end

	---@param character Model
	local function onLiveRemoved(character)
		if not OwnershipWatcher.modelsToScan[character] then

			return
		end

		OwnershipWatcher.modelsToScan[character]:clean()
		OwnershipWatcher.modelsToScan[character] = nil
	end

	local function updateOwnership()




		---@optimization: Stop updating when we don't need it.
		if
			not Configuration.expectToggleValue("ShowOwnership")
			and not Configuration.expectToggleValue("VoidMobs")
			and not EchoFarm.voiding
		then
			return cleanParts()
		end

		local updateTable = {}

		for model, maid in next, OwnershipWatcher.modelsToScan do
			local humanoidRootPart = model:FindFirstChild("HumanoidRootPart")
			if not humanoidRootPart then
				continue
			end

			local isNetworkOwner = hasNetworkOwnership(humanoidRootPart)

			local netVisual = InstanceWrapper.create(maid, "NetworkVisual", "Part", model)
			netVisual.Size = Vector3.new(10, 10, 10)
			netVisual.Transparency = Configuration.expectToggleValue("ShowOwnership") and 0.8 or 1.0
			netVisual.Color = isNetworkOwner and Color3.fromRGB(0, 255, 0) or Color3.fromRGB(255, 0, 0)
			netVisual.CFrame = humanoidRootPart.CFrame
			netVisual.Anchored = true
			netVisual.CanCollide = false

			local data = OwnershipWatcher.parts[humanoidRootPart]
				or {
					owned = isNetworkOwner,
					model = model,
				}

			data.owned = isNetworkOwner
			data.model = model

			OwnershipWatcher.parts[humanoidRootPart] = data

			updateTable[humanoidRootPart] = data
		end

		---@note: This will get rid of any parts that were not updated (e.g no longer existing root part or not in model list) upon cycle.
		---@todo: Fix me - this is a bit of a hack.
		OwnershipWatcher.parts = updateTable
	end

	---@return table<BasePart, table>
	function OwnershipWatcher.get()
		return OwnershipWatcher.parts
	end

	function OwnershipWatcher.init()
		local live = workspace:WaitForChild("Live")
		local liveChildAdded = Signal.new(live.ChildAdded)
		local liveChildRemoved = Signal.new(live.ChildRemoved)

		ownershipMaid:add(liveChildAdded:connect("OwnershipWatcher_OnLiveChildAdded", onLiveAdded))
		ownershipMaid:add(liveChildRemoved:connect("OwnershipWatcher_OnLiveChildRemoved", onLiveRemoved))
		ownershipMaid:add(renderStepped:connect("OwnershipWatcher_RenderStepped", throttle(1 / 20, updateOwnership)))

		for _, entity in next, live:GetChildren() do
			onLiveAdded(entity)
		end

		if not LPH_OBFUSCATED or shared.Luma.verbose then
			Logger.warn("OwnershipWatcher initialized.")
		end
	end

	function OwnershipWatcher.detach()
		ownershipMaid:clean()

		cleanParts()

		Logger.warn("OwnershipWatcher detached.")
	end

	return OwnershipWatcher
end)()