---@type PartTiming
local PartTiming = getfenv().PartTiming

---@type Action
local Action = getfenv().Action

---@type ProjectileTracker
---@diagnostic disable-next-line: unused-local
local ProjectileTracker = getfenv().ProjectileTracker

---@module Features.Combat.Defense
local Defense = getfenv().Defense

---@module Game.Latency
local Latency = getfenv().Latency

---Module function.
---@param self AnimatorDefender
---@param timing AnimationTiming
return function(self, timing)
	task.spawn(function()
		local thrown = workspace:FindFirstChild("Thrown")
		if not thrown then
			return
		end

		local tracker = ProjectileTracker.new(function(candidate)
			return candidate.Name == "IceShuriken"
		end)

		task.wait(0.9 - Latency.rtt())

		if self:distance(self.entity) <= 15 then
			local action = Action.new()
			action._type = "Start Block"
			action._when = 800
			action.name = "Ice Forge Close Timing"
			action.fhb = true
			action.ihbc = false
			self:action(timing, action)

			local actionTwo = Action.new()
			actionTwo._type = "End Block"
			actionTwo._when = 1000
			actionTwo.fhb = true
			actionTwo.ihbc = false
			self:action(timing, actionTwo)
		end

		local action = Action.new()
		action._when = 0
		action._type = "Start Block"
		action.name = "Ice Forge Part"

		local actionTwo = Action.new()
		actionTwo._when = 300
		actionTwo._type = "End Block"
		actionTwo.name = "Ice Forge Part"

		local pt = PartTiming.new()
		pt.uhc = true
		pt.duih = true
		pt.fhb = false
		pt.name = "IceForgeProjectile"
		pt.hitbox = Vector3.new(35, 35, 35)
		pt.actions:push(action)
		pt.cbm = true

		Defense.cdpo(tracker:wait(), pt)
	end)
end
