---@class Action
local Action = getfenv().Action

---@module Modules.Globals.Mantra
local Mantra = getfenv().Mantra

---Module function.
---@param self AnimatorDefender
---@param timing AnimationTiming
return function(self, timing)
	local data = Mantra.data(self.entity, "Mantra:PalmFire{{Fire Palm}}")
	local range = data.stratus * 3 + data.cloud * 2

	local hrp = self.entity:FindFirstChild("HumanoidRootPart")
	if not hrp then
		return
	end

	if hrp:WaitForChild("REP_SOUND_4377231054", 0.1) then
		local action = Action.new()
		action._when = 450
		action._type = "Parry"
		action.hitbox = Vector3.new(30, 20, 30)
		action.name = "Gale Punch Timing"
		return self:action(timing, action)
	else
		local action = Action.new()
		action._when = 300
		action._type = "Parry"
		action.hitbox = Vector3.new(25, 25, 40 + range)
		action.name = "Fire Palm Timing"
		return self:action(timing, action)
	end
end
